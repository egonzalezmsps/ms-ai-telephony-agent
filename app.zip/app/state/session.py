"""
state/session.py

Estado de sesión de ReniAgent — simplificado para arquitectura Strands nativa.

En Strands no necesitamos los flags del router (awaiting_*, active_scenario, etc.)
porque el modelo razona directamente. Solo necesitamos:
1. Datos del cliente (quién es, qué plan tiene)
2. Plan recomendado (calculado una vez al inicio)
3. Estado de la contratación (si ya aceptó y qué plan)
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SessionState:
    """Estado de sesión minimalista para ReniAgent Strands."""

    # ── Identidad ─────────────────────────────────────────────────
    first_name: str = ""
    full_name: str = ""
    phone_number: str = ""
    api_phone_number: Optional[str] = None  # teléfono para call_create_process (Cliente.lineaApi); si no hay, se usa phone_number

    # ── Plan actual ───────────────────────────────────────────────
    current_plan_name: str = ""
    previous_plan_name: str = ""
    current_cost: float = 0.0
    current_plan_gb: Optional[float] = None
    current_plan_cashback: Optional[float] = None
    subscription_type: str = "Abierto"      # "Abierto" | "Controlado"

    # ── Promoción ─────────────────────────────────────────────────
    has_promotion: bool = True
    fecha_vigencia: str = "30/05/2026"

    # ── Perfil de uso ─────────────────────────────────────────────
    usage_summary: Optional[str] = None

    # ── Contratación ─────────────────────────────────────────────
    plan_selected: Optional[str] = None     # plan que el cliente aceptó activar
    plan_anclado: str = ""                  # plan contextual activo para preguntas de cierre
    rejection_count: int = 0               # contador de rechazos para manejo de objeciones
    stage: str = "PERSUASION"               # PERSUASION | CONTRACT | POST_SALE | END
    end_reason: str = ""                    # "success" | "blocked"
    esperando_criterio_recomendacion: bool = False  # esperando respuesta a "¿qué prefiere?"

    # ── Titular ───────────────────────────────────────────────────
    is_titular: bool = True
    nombre_incorrecto: bool = False
    cac_nombre_incorrecto_shown: bool = False
    post_not_titular: bool = False

    # ── Flujo de contratación ─────────────────────────────────────
    awaiting_contract_confirmation: bool = False
    awaiting_otp: bool = False
    otp_sent: bool = False
    otp_attempt_count: int = 0
    otp_resend_count: int = 0
    is_authenticated: bool = False
    authentication_locked: bool = False
    contract_folio: Optional[str] = None
    process_id_api: Optional[str] = None

